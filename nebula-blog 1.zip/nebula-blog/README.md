# Nebula Blog — Starter

A runnable, end-to-end blog platform starter with cinematic 3D, ambient motion, and a writer-first editor.

This repo is **a starting point**, not a finished product. It is opinionated, runnable in one command, and structured so you can grow it without painting yourself into a corner.

## Stack

**Frontend** — Next.js 15 (App Router) · React 19 · TypeScript · Tailwind CSS · Framer Motion · Three.js + React Three Fiber + drei · TanStack Query · Zustand · Axios

**Backend** — Java 21 · Spring Boot 3.3 · Spring Security · JWT (jjwt) · Spring Data MongoDB · Bean Validation · springdoc-openapi (Swagger UI)

**Infra** — Docker · Docker Compose · MongoDB 7

## What's included

- Auth: register / login / refresh / logout (stateless JWT with access + refresh tokens, password hashing, validation)
- Posts: CRUD, drafts/published, slug auto-generation, full-text search, tag filtering, like/bookmark, view count, reading-time estimate
- Comments: nested threads
- Users: profiles, follow/unfollow
- 3D: hero scene with parallax orbits + crystal mesh; ambient nebula scene on the reading page; both respect `prefers-reduced-motion`
- Card hover: spring-driven 3D tilt + spotlight gradient on every post card
- Markdown rendering with GFM
- Reading-progress indicator on post pages
- Seed data so the app shows real content the moment it boots
- OpenAPI/Swagger UI at `/swagger-ui.html`
- Dockerfile per service + a single `docker compose up` for everything
- One smoke test that boots the Spring context against an embedded MongoDB

## Quick start (Docker — recommended)

You need Docker Desktop / Docker Engine 24+.

```bash
cp .env.example .env          # edit JWT_SECRET (32+ bytes)
docker compose up --build
```

Then open:

- App — http://localhost:3000
- API — http://localhost:8080
- Swagger UI — http://localhost:8080/swagger-ui.html

Demo accounts (created by the seeder):

| email                 | password      |
|-----------------------|---------------|
| `nova@nebula.dev`     | `password123` |
| `orion@nebula.dev`    | `password123` |

## Quick start (local dev)

You'll need: JDK 21, Maven 3.9+, Node 20+, MongoDB 7 (or run `docker compose up mongo`).

**Backend**

```bash
cd backend
export MONGODB_URI=mongodb://localhost:27017/nebula_blog
export JWT_SECRET=please-change-me-to-a-long-random-string-32-bytes-min
./mvnw spring-boot:run        # or: mvn spring-boot:run
```

**Frontend**

```bash
cd frontend
cp .env.example .env.local
npm install --legacy-peer-deps
npm run dev
```

The frontend's `next.config.mjs` rewrites `/api/*` to the backend, so the browser sees same-origin requests.

## Project layout

```
nebula-blog/
├─ backend/              Spring Boot service
│  └─ src/main/java/com/nebula/blog/
│     ├─ auth/           Register, login, refresh, JWT issuance
│     ├─ user/           Profiles, follow/unfollow
│     ├─ post/           CRUD, like, bookmark, search, slugify
│     ├─ comment/        Nested comments
│     ├─ security/       JWT filter, UserDetails, Spring Security config
│     ├─ config/         Properties, CORS, OpenAPI, seeder
│     ├─ exception/      Global handler + domain exceptions
│     └─ common/         ApiError, PageResponse
├─ frontend/             Next.js app
│  └─ src/
│     ├─ app/            App Router pages (home, login, register, /p/[slug], /u/[username], /editor)
│     ├─ components/
│     │  ├─ blog/        PostCard, MarkdownContent, CommentsThread, ReadingProgress, ...
│     │  ├─ three/       HeroScene, AmbientScene
│     │  └─ ui/          Button, Input, Textarea, TagPill
│     ├─ lib/            API client, types, auth store
│     └─ hooks/          useReducedMotion
├─ docker-compose.yml
└─ .env.example
```

## API surface

All routes are under `/api`. Authenticated endpoints accept `Authorization: Bearer <accessToken>`.

| Method | Path                                    | Auth | Description                              |
|--------|-----------------------------------------|:----:|------------------------------------------|
| POST   | `/api/auth/register`                    |   –  | Create account, returns access + refresh |
| POST   | `/api/auth/login`                       |   –  | Sign in with email/username + password   |
| POST   | `/api/auth/refresh`                     |   –  | Exchange refresh for new access token    |
| POST   | `/api/auth/logout`                      |   –  | Client-side token clear (see notes)      |
| GET    | `/api/users/me`                         |   ✓  | Current user profile                     |
| PATCH  | `/api/users/me`                         |   ✓  | Update display name, bio, avatar         |
| GET    | `/api/users/{username}`                 |   –  | Public profile                           |
| POST   | `/api/users/{userId}/follow`            |   ✓  | Follow a user                            |
| DELETE | `/api/users/{userId}/follow`            |   ✓  | Unfollow                                 |
| GET    | `/api/posts`                            |   –  | List published posts (`?page&size&tag&search`) |
| GET    | `/api/posts/{slug}`                     |  opt | Get post by slug; auth lets author view drafts |
| POST   | `/api/posts`                            |   ✓  | Create post (draft or published)         |
| PATCH  | `/api/posts/{postId}`                   |   ✓  | Update (author only)                     |
| DELETE | `/api/posts/{postId}`                   |   ✓  | Delete (author only)                     |
| POST   | `/api/posts/{postId}/like`              |   ✓  | Toggle like                              |
| POST   | `/api/posts/{postId}/bookmark`          |   ✓  | Toggle bookmark                          |
| GET    | `/api/posts/{postId}/comments`          |   –  | Threaded comments                        |
| POST   | `/api/posts/{postId}/comments`          |   ✓  | Add comment (optional `parentId`)        |
| DELETE | `/api/comments/{commentId}`             |   ✓  | Delete comment (author only)             |

Full schemas in Swagger UI.

## Configuration

### Backend env vars

| Var                  | Default                            | Notes                              |
|----------------------|------------------------------------|------------------------------------|
| `SERVER_PORT`        | `8080`                             |                                    |
| `MONGODB_URI`        | `mongodb://localhost:27017/nebula_blog` |                               |
| `JWT_SECRET`         | dev fallback                       | **Must be ≥32 bytes** in production |
| `JWT_ACCESS_TTL`     | `3600` (seconds)                   | 1 hour access token                |
| `JWT_REFRESH_TTL`    | `1209600` (seconds)                | 14 day refresh token               |
| `CORS_ORIGINS`       | `http://localhost:3000`            | Comma-separated                    |

### Frontend env vars

| Var                   | Default                  | Notes                                              |
|-----------------------|--------------------------|----------------------------------------------------|
| `NEXT_PUBLIC_API_URL` | `http://localhost:8080`  | Used for SSR fetches & to build the `/api` rewrite |

## Performance & accessibility

- 3D scenes degrade gracefully: `useReducedMotion` cuts particle counts and stops rotation when `prefers-reduced-motion: reduce` is set.
- The ambient scene on the reading page uses `powerPreference: 'low-power'` and a radial mask so it never competes with the content.
- All canvases mount client-side via `next/dynamic({ ssr: false })`, so the first byte is HTML, not WebGL.
- Card hover uses Framer Motion springs (GPU-accelerated transforms) — no layout thrash.
- Tailwind purges unused CSS; React Query handles caching/dedupe; Axios uses a single in-flight refresh promise to avoid stampedes.

## Security notes (read this)

- `JWT_SECRET` is the one knob you **must** change. The default is fine for local dev only.
- Tokens live in `localStorage` for simplicity. For higher-security deployments, switch refresh tokens to an HTTP-only `Secure` cookie and add CSRF protection.
- Logout is currently client-side (drop the tokens). For hard logout, store refresh-token JTIs in Redis and check them in the refresh endpoint.
- `Content-Security-Policy` is set to `default-src 'self'` — adjust if you embed third-party scripts.

## Extension points (deliberately not implemented)

These are stubbed or marked as TODOs because they need real infrastructure or credentials you should provide:

- **OAuth2 Google / GitHub** — add `spring-boot-starter-oauth2-client`, configure providers, exchange the OAuth principal for a Nebula JWT in `AuthController`. Frontend hits `/oauth2/authorization/google`.
- **Refresh-token blacklist / hard logout** — Redis + a `JwtRevocationStore` checked in `JwtService.parse` and `AuthService.refresh`.
- **WebSocket notifications** — add `spring-boot-starter-websocket` and a `/ws` STOMP endpoint; emit on like/comment events.
- **Search at scale** — current full-text search uses MongoDB's text index, which is fine up to ~100k posts. Beyond that, swap in Elasticsearch via `spring-data-elasticsearch`.
- **Image uploads** — accept multipart, push to S3 / Cloudinary, return a URL. The post and user models already store URL fields.
- **Admin dashboard** — `ROLE_ADMIN` is seeded; add `@PreAuthorize("hasRole('ADMIN')")` controllers and a `/admin` route group.
- **AI features** — recommendations, summaries, voice. Wire to your provider in a new `ai-service` package.
- **CI/CD** — add `.github/workflows/ci.yml` running `mvn test` and `npm run build`.
- **Analytics** — `viewCount` is incremented on read. Add an `events` collection or a real analytics pipeline for engagement.

## Tests

The backend ships with one smoke test (`NebulaBlogApplicationTests`) that boots the Spring context against an embedded Mongo. Run:

```bash
cd backend && ./mvnw test
```

This is intentionally minimal — add controller/integration tests as you build.

## Troubleshooting

- **`JWT secret must be at least 32 bytes`** on backend startup — your `JWT_SECRET` env var is too short. Use at least 32 ASCII characters.
- **CORS errors** in the browser — set `CORS_ORIGINS` to include your frontend's exact origin.
- **`npm install` complains about peer deps** — React 19 RC requires `--legacy-peer-deps`. The Dockerfile already passes this.
- **Three.js complains about `THREE` namespace** — the import path `'three'` is correct; if you add post-processing or addons, prefer the `three/examples/jsm/...` paths.

## License

MIT — do whatever you want, no warranty.
