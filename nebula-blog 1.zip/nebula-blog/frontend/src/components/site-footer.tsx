export function SiteFooter() {
  return (
    <footer className="mt-24 border-t border-white/5">
      <div className="mx-auto max-w-7xl px-6 py-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <p className="font-display text-lg gradient-text">Nebula</p>
          <p className="text-sm text-ink-faint mt-1">A modern publishing platform — built as a starter.</p>
        </div>
        <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-ink-dim">
          <a href="/api/v3/api-docs" className="hover:text-ink transition-colors">API docs</a>
          <a href="https://github.com" className="hover:text-ink transition-colors">GitHub</a>
          <span className="text-ink-faint">© {new Date().getFullYear()} Nebula</span>
        </div>
      </div>
    </footer>
  );
}
