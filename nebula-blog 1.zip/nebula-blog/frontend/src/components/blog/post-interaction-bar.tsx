'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { toggleBookmark, toggleLike } from '@/lib/endpoints';
import type { PostDetail } from '@/lib/types';
import { useAuth } from '@/lib/auth-store';
import { useRouter } from 'next/navigation';

export function PostInteractionBar({ post }: { post: PostDetail }) {
  const [liked, setLiked] = useState(post.likedByMe);
  const [likeCount, setLikeCount] = useState(post.likeCount);
  const [bookmarked, setBookmarked] = useState(post.bookmarkedByMe);
  const [busy, setBusy] = useState(false);

  const user = useAuth((s) => s.user);
  const router = useRouter();

  async function onLike() {
    if (!user) {
      router.push('/login');
      return;
    }
    if (busy) return;
    setBusy(true);
    // optimistic
    setLiked((p) => !p);
    setLikeCount((c) => c + (liked ? -1 : 1));
    try {
      const res = await toggleLike(post.id);
      setLiked(res.likedByMe);
      setLikeCount(res.likeCount);
    } catch {
      // rollback
      setLiked((p) => !p);
      setLikeCount((c) => c + (liked ? 1 : -1));
    } finally {
      setBusy(false);
    }
  }

  async function onBookmark() {
    if (!user) {
      router.push('/login');
      return;
    }
    if (busy) return;
    setBusy(true);
    setBookmarked((p) => !p);
    try {
      const res = await toggleBookmark(post.id);
      setBookmarked(res.bookmarkedByMe);
    } catch {
      setBookmarked((p) => !p);
    } finally {
      setBusy(false);
    }
  }

  async function onShare() {
    const url = typeof window !== 'undefined' ? window.location.href : '';
    if (navigator.share) {
      try {
        await navigator.share({ title: post.title, url });
      } catch {/* user cancelled */}
    } else if (navigator.clipboard) {
      await navigator.clipboard.writeText(url);
    }
  }

  return (
    <div className="glass rounded-full px-2 py-2 flex items-center gap-1">
      <ActionButton onClick={onLike} active={liked} label={`${likeCount}`}>
        <HeartIcon filled={liked} />
      </ActionButton>
      <ActionButton onClick={onBookmark} active={bookmarked} label="">
        <BookmarkIcon filled={bookmarked} />
      </ActionButton>
      <ActionButton onClick={onShare} active={false} label="">
        <ShareIcon />
      </ActionButton>
    </div>
  );
}

function ActionButton({
  children,
  onClick,
  active,
  label,
}: {
  children: React.ReactNode;
  onClick: () => void;
  active: boolean;
  label: string;
}) {
  return (
    <motion.button
      whileTap={{ scale: 0.92 }}
      onClick={onClick}
      className={
        'h-10 min-w-10 px-3 rounded-full flex items-center gap-2 transition-colors text-sm ' +
        (active ? 'text-white bg-white/[0.08]' : 'text-ink-dim hover:text-white hover:bg-white/[0.06]')
      }
    >
      {children}
      {label && <span className="tabular-nums">{label}</span>}
    </motion.button>
  );
}

function HeartIcon({ filled }: { filled: boolean }) {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill={filled ? '#ff7ad6' : 'none'} stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
    </svg>
  );
}
function BookmarkIcon({ filled }: { filled: boolean }) {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill={filled ? '#ffb45a' : 'none'} stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" />
    </svg>
  );
}
function ShareIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="18" cy="5" r="3" />
      <circle cx="6" cy="12" r="3" />
      <circle cx="18" cy="19" r="3" />
      <line x1="8.59" y1="13.51" x2="15.42" y2="17.49" />
      <line x1="15.41" y1="6.51" x2="8.59" y2="10.49" />
    </svg>
  );
}
