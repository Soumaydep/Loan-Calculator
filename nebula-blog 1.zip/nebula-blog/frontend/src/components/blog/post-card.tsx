'use client';

import Link from 'next/link';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import type { MouseEvent } from 'react';
import type { PostSummary } from '@/lib/types';
import { useReducedMotion } from '@/hooks/use-reduced-motion';

export function PostCard({ post, priority = false }: { post: PostSummary; priority?: boolean }) {
  const reduced = useReducedMotion();

  const rotateXRaw = useMotionValue(0);
  const rotateYRaw = useMotionValue(0);
  const rotateX = useSpring(rotateXRaw, { stiffness: 200, damping: 20 });
  const rotateY = useSpring(rotateYRaw, { stiffness: 200, damping: 20 });

  // Pointer-tracked highlight for "spotlight" effect
  const px = useMotionValue(50);
  const py = useMotionValue(50);
  const background = useTransform(
    [px, py],
    ([x, y]) =>
      `radial-gradient(420px circle at ${x}% ${y}%, rgba(160,107,255,0.18), transparent 40%)`
  );

  function onMove(e: MouseEvent<HTMLDivElement>) {
    if (reduced) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const cx = (e.clientX - rect.left) / rect.width; // 0..1
    const cy = (e.clientY - rect.top) / rect.height;
    rotateYRaw.set((cx - 0.5) * 8);
    rotateXRaw.set(-(cy - 0.5) * 8);
    px.set(cx * 100);
    py.set(cy * 100);
  }
  function onLeave() {
    rotateXRaw.set(0);
    rotateYRaw.set(0);
  }

  const author = post.author;
  const initials = author?.displayName?.[0]?.toUpperCase() ?? '?';

  return (
    <motion.article
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      style={{ rotateX, rotateY, transformPerspective: 1200, transformStyle: 'preserve-3d' }}
      className="group relative h-full"
      initial={{ opacity: 0, y: 12 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
    >
      <Link
        href={`/p/${post.slug}`}
        className="block h-full glass rounded-2xl overflow-hidden ring-focus hover:border-white/20 hover:shadow-glow transition-[border-color,box-shadow] duration-300"
      >
        <motion.div
          aria-hidden
          className="pointer-events-none absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
          style={{ background }}
        />

        <div className="relative aspect-[16/9] overflow-hidden bg-bg-soft">
          {post.coverImageUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={post.coverImageUrl}
              alt=""
              loading={priority ? 'eager' : 'lazy'}
              className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04]"
            />
          ) : (
            <div className="h-full w-full bg-mesh-aurora" />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-bg/80 via-bg/0 to-transparent" />
        </div>

        <div className="p-5 flex flex-col gap-3">
          <div className="flex flex-wrap gap-1.5">
            {post.tags.slice(0, 3).map((t) => (
              <span
                key={t}
                className="text-[10px] uppercase tracking-wider text-ink-dim bg-white/[0.04] border border-white/10 rounded-full px-2 py-0.5"
              >
                #{t}
              </span>
            ))}
          </div>

          <h3 className="font-display text-lg leading-snug text-ink group-hover:text-white transition-colors line-clamp-2">
            {post.title}
          </h3>

          <p className="text-sm text-ink-dim leading-relaxed line-clamp-2">{post.excerpt}</p>

          <div className="flex items-center justify-between pt-2 mt-auto">
            <div className="flex items-center gap-2">
              {author?.avatarUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={author.avatarUrl} alt="" className="w-6 h-6 rounded-full" />
              ) : (
                <div className="w-6 h-6 rounded-full bg-gradient-to-br from-accent-electric to-accent-neon grid place-items-center text-[10px] font-semibold">
                  {initials}
                </div>
              )}
              <span className="text-xs text-ink-dim">{author?.displayName ?? 'Unknown'}</span>
            </div>
            <span className="text-xs text-ink-faint">{post.readingMinutes} min read</span>
          </div>
        </div>
      </Link>
    </motion.article>
  );
}
