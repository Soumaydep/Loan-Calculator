'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08, delayChildren: 0.1 } },
};
const item = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] } },
};

export function HomeHero() {
  return (
    <div className="relative mx-auto max-w-7xl px-6 pt-16 pb-28 md:pt-28 md:pb-40 min-h-[80svh] grid place-items-center">
      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="text-center max-w-3xl"
      >
        <motion.span
          variants={item}
          className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass text-xs uppercase tracking-[0.18em] text-ink-dim"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-accent-aurora animate-pulse" />
          A new kind of publishing
        </motion.span>

        <motion.h1
          variants={item}
          className="mt-6 font-display text-5xl md:text-7xl leading-[1.02] tracking-tight"
        >
          Stories from the <span className="gradient-text">future</span> of the web.
        </motion.h1>

        <motion.p variants={item} className="mt-6 text-lg text-ink-dim leading-relaxed">
          Nebula is a writer-first publishing platform with cinematic motion, ambient 3D, and an
          editor that gets out of your way.
        </motion.p>

        <motion.div variants={item} className="mt-10 flex flex-wrap items-center justify-center gap-3">
          <Link href="/register">
            <Button size="lg">Start writing</Button>
          </Link>
          <Link href="#latest">
            <Button size="lg" variant="glass">
              Read the feed
            </Button>
          </Link>
        </motion.div>
      </motion.div>
    </div>
  );
}
