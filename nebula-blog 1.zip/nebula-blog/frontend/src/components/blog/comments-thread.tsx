'use client';

import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { createComment, fetchComments } from '@/lib/endpoints';
import type { CommentNode } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useAuth } from '@/lib/auth-store';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';

export function CommentsThread({ postId }: { postId: string }) {
  const { data, isLoading } = useQuery({
    queryKey: ['comments', postId],
    queryFn: () => fetchComments(postId),
  });

  return (
    <section className="mt-16">
      <h2 className="font-display text-2xl mb-6">Discussion</h2>
      <CommentForm postId={postId} />
      <div className="mt-8 flex flex-col gap-6">
        {isLoading && <p className="text-ink-faint text-sm">Loading…</p>}
        {data && data.length === 0 && (
          <p className="text-ink-faint text-sm">No comments yet. Be the first.</p>
        )}
        <AnimatePresence initial={false}>
          {data?.map((c) => <CommentItem key={c.id} node={c} postId={postId} depth={0} />)}
        </AnimatePresence>
      </div>
    </section>
  );
}

function CommentForm({
  postId,
  parentId,
  onDone,
}: {
  postId: string;
  parentId?: string | null;
  onDone?: () => void;
}) {
  const [content, setContent] = useState('');
  const user = useAuth((s) => s.user);
  const qc = useQueryClient();

  const mut = useMutation({
    mutationFn: () => createComment(postId, { content, parentId: parentId ?? null }),
    onSuccess: () => {
      setContent('');
      qc.invalidateQueries({ queryKey: ['comments', postId] });
      onDone?.();
    },
  });

  if (!user) {
    return (
      <div className="glass rounded-2xl p-5 text-sm text-ink-dim">
        <Link href="/login" className="text-accent-electric hover:underline">Sign in</Link> to join the conversation.
      </div>
    );
  }

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (content.trim().length === 0) return;
        mut.mutate();
      }}
      className="flex flex-col gap-3"
    >
      <Textarea
        placeholder={parentId ? 'Reply…' : 'Share your thoughts'}
        value={content}
        onChange={(e) => setContent(e.target.value)}
        className="min-h-[90px]"
      />
      <div className="flex justify-end gap-2">
        {onDone && (
          <Button type="button" variant="ghost" size="sm" onClick={onDone}>Cancel</Button>
        )}
        <Button type="submit" size="sm" disabled={mut.isPending || content.trim().length === 0}>
          {mut.isPending ? 'Posting…' : parentId ? 'Reply' : 'Comment'}
        </Button>
      </div>
    </form>
  );
}

function CommentItem({ node, postId, depth }: { node: CommentNode; postId: string; depth: number }) {
  const [replying, setReplying] = useState(false);
  const initials = node.author?.displayName?.[0]?.toUpperCase() ?? '?';

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.25 }}
      className={depth > 0 ? 'ml-6 pl-5 border-l border-white/10' : ''}
    >
      <div className="flex gap-3">
        {node.author?.avatarUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={node.author.avatarUrl} alt="" className="w-8 h-8 rounded-full mt-0.5" />
        ) : (
          <div className="w-8 h-8 rounded-full mt-0.5 bg-gradient-to-br from-accent-electric to-accent-neon grid place-items-center text-xs font-semibold">
            {initials}
          </div>
        )}
        <div className="flex-1 min-w-0">
          <div className="flex items-baseline gap-2">
            <span className="font-medium text-ink">{node.author?.displayName ?? 'Unknown'}</span>
            <span className="text-xs text-ink-faint">
              {new Date(node.createdAt).toLocaleDateString()}
            </span>
          </div>
          <p className="text-ink-dim mt-1 whitespace-pre-wrap leading-relaxed">{node.content}</p>
          {depth < 3 && (
            <button
              onClick={() => setReplying((v) => !v)}
              className="text-xs text-ink-faint hover:text-ink mt-2 transition-colors"
            >
              {replying ? 'Cancel' : 'Reply'}
            </button>
          )}
          {replying && (
            <div className="mt-3">
              <CommentForm postId={postId} parentId={node.id} onDone={() => setReplying(false)} />
            </div>
          )}
        </div>
      </div>
      {node.replies.length > 0 && (
        <div className="mt-4 flex flex-col gap-4">
          {node.replies.map((r) => (
            <CommentItem key={r.id} node={r} postId={postId} depth={depth + 1} />
          ))}
        </div>
      )}
    </motion.div>
  );
}
