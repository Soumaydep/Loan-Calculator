'use client';

import Link from 'next/link';
import { useAuth } from '@/lib/auth-store';
import { Button } from './ui/button';
import { motion } from 'framer-motion';
import { useRouter } from 'next/navigation';

export function SiteHeader() {
  const user = useAuth((s) => s.user);
  const initialized = useAuth((s) => s.initialized);
  const logout = useAuth((s) => s.logout);
  const router = useRouter();

  return (
    <header className="sticky top-0 z-40 backdrop-blur-xl bg-bg/60 border-b border-white/5">
      <div className="mx-auto max-w-7xl px-6 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group">
          <motion.span
            initial={{ rotate: 0 }}
            animate={{ rotate: 360 }}
            transition={{ duration: 18, repeat: Infinity, ease: 'linear' }}
            className="block w-7 h-7 rounded-lg bg-gradient-to-br from-accent-electric via-accent-neon to-accent-cyan shadow-glow"
          />
          <span className="font-display text-lg font-semibold tracking-tight">Nebula</span>
        </Link>

        <nav className="hidden md:flex items-center gap-1 text-sm">
          <Link href="/" className="px-3 py-2 rounded-lg text-ink-dim hover:text-ink hover:bg-white/[0.04] transition-colors">
            Feed
          </Link>
          <Link href="/?tab=trending" className="px-3 py-2 rounded-lg text-ink-dim hover:text-ink hover:bg-white/[0.04] transition-colors">
            Trending
          </Link>
          {user && (
            <Link href="/editor" className="px-3 py-2 rounded-lg text-ink-dim hover:text-ink hover:bg-white/[0.04] transition-colors">
              Write
            </Link>
          )}
        </nav>

        <div className="flex items-center gap-2">
          {!initialized ? (
            <div className="h-9 w-24 rounded-lg bg-white/[0.03] animate-pulse" />
          ) : user ? (
            <>
              <Link
                href={`/u/${user.username}`}
                className="hidden sm:flex items-center gap-2 px-2 py-1 rounded-lg hover:bg-white/[0.04] transition-colors"
              >
                {user.avatarUrl && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={user.avatarUrl} alt="" className="w-7 h-7 rounded-full" />
                )}
                <span className="text-sm text-ink">{user.displayName}</span>
              </Link>
              <Button
                variant="subtle"
                size="sm"
                onClick={async () => {
                  await logout();
                  router.push('/');
                }}
              >
                Sign out
              </Button>
            </>
          ) : (
            <>
              <Link href="/login">
                <Button variant="ghost" size="sm">Sign in</Button>
              </Link>
              <Link href="/register">
                <Button size="sm">Get started</Button>
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
