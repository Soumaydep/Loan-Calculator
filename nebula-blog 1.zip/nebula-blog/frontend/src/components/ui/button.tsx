'use client';

import { forwardRef, type ButtonHTMLAttributes } from 'react';
import { cn } from '@/lib/cn';

type Variant = 'primary' | 'ghost' | 'glass' | 'subtle';
type Size = 'sm' | 'md' | 'lg';

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
}

const variants: Record<Variant, string> = {
  primary:
    'bg-gradient-to-r from-accent-electric via-accent-neon to-accent-cyan text-white shadow-glow hover:shadow-glow-lg hover:brightness-110 active:scale-[0.98]',
  glass:
    'glass text-ink hover:bg-white/[0.07] hover:border-white/20 active:scale-[0.98]',
  ghost:
    'bg-transparent text-ink hover:text-white hover:bg-white/[0.05]',
  subtle:
    'bg-white/[0.04] border border-white/10 text-ink hover:bg-white/[0.08] hover:border-white/20',
};

const sizes: Record<Size, string> = {
  sm: 'h-9 px-3 text-sm rounded-lg',
  md: 'h-11 px-5 text-sm rounded-xl',
  lg: 'h-12 px-7 text-base rounded-2xl',
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { className, variant = 'primary', size = 'md', ...rest },
  ref
) {
  return (
    <button
      ref={ref}
      className={cn(
        'inline-flex items-center justify-center gap-2 font-medium transition-[transform,box-shadow,background-color,filter] duration-200 ring-focus disabled:opacity-50 disabled:cursor-not-allowed',
        variants[variant],
        sizes[size],
        className
      )}
      {...rest}
    />
  );
});
