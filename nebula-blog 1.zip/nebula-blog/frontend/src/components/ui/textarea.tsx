'use client';

import { forwardRef, type TextareaHTMLAttributes } from 'react';
import { cn } from '@/lib/cn';

export interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(function Textarea(
  { className, label, id, ...rest },
  ref
) {
  const textareaId = id ?? rest.name;
  return (
    <div className="flex flex-col gap-1.5">
      {label && (
        <label htmlFor={textareaId} className="text-xs font-medium uppercase tracking-wider text-ink-dim">
          {label}
        </label>
      )}
      <textarea
        ref={ref}
        id={textareaId}
        className={cn(
          'min-h-[120px] px-4 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-ink placeholder:text-ink-faint resize-y',
          'transition-[box-shadow,border-color] duration-200',
          'focus:outline-none focus:border-accent-electric/60 focus:bg-white/[0.05] focus:shadow-[0_0_0_4px_rgba(91,140,255,0.12)]',
          className
        )}
        {...rest}
      />
    </div>
  );
});
