'use client';

import { forwardRef, type InputHTMLAttributes } from 'react';
import { cn } from '@/lib/cn';

export interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(function Input(
  { className, label, error, id, ...rest },
  ref
) {
  const inputId = id ?? rest.name;
  return (
    <div className="flex flex-col gap-1.5">
      {label && (
        <label htmlFor={inputId} className="text-xs font-medium uppercase tracking-wider text-ink-dim">
          {label}
        </label>
      )}
      <input
        ref={ref}
        id={inputId}
        className={cn(
          'h-11 px-4 rounded-xl bg-white/[0.03] border border-white/10 text-ink placeholder:text-ink-faint',
          'transition-[box-shadow,border-color,background-color] duration-200',
          'focus:outline-none focus:border-accent-electric/60 focus:bg-white/[0.05] focus:shadow-[0_0_0_4px_rgba(91,140,255,0.12)]',
          error && 'border-rose-500/50 focus:border-rose-500/70 focus:shadow-[0_0_0_4px_rgba(244,63,94,0.12)]',
          className
        )}
        {...rest}
      />
      {error && <p className="text-xs text-rose-400">{error}</p>}
    </div>
  );
});
