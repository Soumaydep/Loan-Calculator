import Link from 'next/link';
import { cn } from '@/lib/cn';

export function TagPill({ tag, className }: { tag: string; className?: string }) {
  return (
    <Link
      href={`/?tag=${encodeURIComponent(tag)}`}
      className={cn(
        'inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-medium uppercase tracking-wider',
        'bg-white/[0.04] text-ink-dim border border-white/10 hover:text-ink hover:border-white/20 transition-colors',
        className
      )}
    >
      <span className="opacity-60 mr-1">#</span>
      {tag}
    </Link>
  );
}
