'use client';

import dynamic from 'next/dynamic';

const AmbientScene = dynamic(() => import('./ambient-scene').then((m) => m.AmbientScene), {
  ssr: false,
  loading: () => null,
});

export function AmbientSceneClient() {
  return <AmbientScene />;
}
