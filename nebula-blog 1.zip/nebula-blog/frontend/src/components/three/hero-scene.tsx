'use client';

import { Canvas, useFrame } from '@react-three/fiber';
import { Float, Environment, Stars } from '@react-three/drei';
import { Suspense, useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useReducedMotion } from '@/hooks/use-reduced-motion';

/** A faceted icosahedron that slowly rotates and subtly pulses. */
function Crystal() {
  const ref = useRef<THREE.Mesh>(null);
  const reduced = useReducedMotion();

  useFrame((state, delta) => {
    if (!ref.current) return;
    if (reduced) return;
    ref.current.rotation.x += delta * 0.12;
    ref.current.rotation.y += delta * 0.18;
    const t = state.clock.elapsedTime;
    const s = 1 + Math.sin(t * 0.6) * 0.02;
    ref.current.scale.set(s, s, s);
  });

  return (
    <mesh ref={ref} castShadow receiveShadow>
      <icosahedronGeometry args={[1.4, 1]} />
      <meshPhysicalMaterial
        color="#a06bff"
        roughness={0.15}
        metalness={0.4}
        clearcoat={1}
        clearcoatRoughness={0.2}
        emissive="#3a1f6e"
        emissiveIntensity={0.25}
        flatShading
      />
    </mesh>
  );
}

/** Orbiting glow ring made from a thin torus. */
function OrbitRing({ radius = 2.4, tilt = 0.5, color = '#39d6ff' }: {
  radius?: number;
  tilt?: number;
  color?: string;
}) {
  const ref = useRef<THREE.Mesh>(null);
  const reduced = useReducedMotion();

  useFrame((_, delta) => {
    if (!ref.current || reduced) return;
    ref.current.rotation.z += delta * 0.15;
  });

  return (
    <mesh ref={ref} rotation={[tilt, 0, 0]}>
      <torusGeometry args={[radius, 0.012, 12, 200]} />
      <meshBasicMaterial color={color} transparent opacity={0.55} />
    </mesh>
  );
}

/** Camera that drifts slightly with the cursor for parallax feel. */
function ParallaxRig({ children }: { children: React.ReactNode }) {
  const group = useRef<THREE.Group>(null);
  const reduced = useReducedMotion();

  useFrame((state) => {
    if (!group.current || reduced) return;
    const { x, y } = state.pointer; // -1..1
    group.current.rotation.y = THREE.MathUtils.lerp(group.current.rotation.y, x * 0.3, 0.05);
    group.current.rotation.x = THREE.MathUtils.lerp(group.current.rotation.x, -y * 0.2, 0.05);
  });

  return <group ref={group}>{children}</group>;
}

/** Soft particles drifting in the background. */
function Particles({ count = 220 }: { count?: number }) {
  const ref = useRef<THREE.Points>(null);
  const reduced = useReducedMotion();

  const { positions, sizes } = useMemo(() => {
    const positions = new Float32Array(count * 3);
    const sizes = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      positions[i * 3 + 0] = (Math.random() - 0.5) * 16;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 10;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 8 - 2;
      sizes[i] = Math.random() * 0.04 + 0.01;
    }
    return { positions, sizes };
  }, [count]);

  useFrame((_, delta) => {
    if (!ref.current || reduced) return;
    ref.current.rotation.y += delta * 0.02;
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
        />
        <bufferAttribute
          attach="attributes-size"
          args={[sizes, 1]}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.045}
        sizeAttenuation
        color="#9bb6ff"
        transparent
        opacity={0.7}
        depthWrite={false}
      />
    </points>
  );
}

export function HeroScene() {
  const reduced = useReducedMotion();

  return (
    <Canvas
      shadows={false}
      dpr={[1, 1.5]}
      camera={{ position: [0, 0, 6], fov: 50 }}
      gl={{ antialias: true, alpha: true, powerPreference: 'high-performance' }}
      style={{ background: 'transparent' }}
    >
      <Suspense fallback={null}>
        <ambientLight intensity={0.6} />
        <directionalLight position={[5, 5, 5]} intensity={1.2} color="#b89bff" />
        <directionalLight position={[-5, -3, -2]} intensity={0.6} color="#39d6ff" />

        <ParallaxRig>
          <Float
            speed={reduced ? 0 : 1.2}
            rotationIntensity={reduced ? 0 : 0.3}
            floatIntensity={reduced ? 0 : 0.6}
          >
            <Crystal />
          </Float>
          <OrbitRing radius={2.2} tilt={0.4} color="#39d6ff" />
          <OrbitRing radius={2.8} tilt={-0.6} color="#a06bff" />
          <OrbitRing radius={3.4} tilt={0.9} color="#5b8cff" />
          <Particles count={reduced ? 60 : 240} />
        </ParallaxRig>

        <Stars radius={50} depth={30} count={reduced ? 400 : 1500} factor={2.4} fade saturation={0} />
        <Environment preset="night" />
      </Suspense>
    </Canvas>
  );
}
