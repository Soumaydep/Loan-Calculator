'use client';

import { Canvas, useFrame } from '@react-three/fiber';
import { Stars } from '@react-three/drei';
import { Suspense, useRef } from 'react';
import * as THREE from 'three';
import { useReducedMotion } from '@/hooks/use-reduced-motion';

function Nebula() {
  const ref = useRef<THREE.Mesh>(null);
  const reduced = useReducedMotion();

  useFrame((state, delta) => {
    if (!ref.current || reduced) return;
    ref.current.rotation.z += delta * 0.02;
    const t = state.clock.elapsedTime;
    (ref.current.material as THREE.MeshBasicMaterial).opacity = 0.25 + Math.sin(t * 0.4) * 0.05;
  });

  return (
    <mesh ref={ref} position={[0, 0, -5]}>
      <planeGeometry args={[40, 22]} />
      <meshBasicMaterial color="#5b8cff" transparent opacity={0.22} depthWrite={false} />
    </mesh>
  );
}

export function AmbientScene() {
  const reduced = useReducedMotion();

  return (
    <div
      aria-hidden
      className="pointer-events-none fixed inset-0 -z-10"
      style={{
        maskImage: 'radial-gradient(ellipse at center, black 50%, transparent 90%)',
        WebkitMaskImage: 'radial-gradient(ellipse at center, black 50%, transparent 90%)',
      }}
    >
      <Canvas
        dpr={[1, 1.25]}
        camera={{ position: [0, 0, 6], fov: 60 }}
        gl={{ antialias: true, alpha: true, powerPreference: 'low-power' }}
        style={{ background: 'transparent' }}
      >
        <Suspense fallback={null}>
          <Nebula />
          <Stars radius={80} depth={40} count={reduced ? 250 : 800} factor={3} fade saturation={0} />
        </Suspense>
      </Canvas>
    </div>
  );
}
