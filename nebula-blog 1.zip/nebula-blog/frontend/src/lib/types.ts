export type UserSummary = {
  id: string;
  username: string;
  displayName: string;
  avatarUrl: string | null;
};

export type UserProfile = {
  id: string;
  username: string;
  email: string;
  displayName: string;
  avatarUrl: string | null;
  bio: string | null;
  followerCount: number;
  followingCount: number;
  roles: string[];
  createdAt: string;
};

export type PostStatus = 'DRAFT' | 'PUBLISHED';

export type PostSummary = {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  coverImageUrl: string | null;
  tags: string[];
  author: UserSummary | null;
  readingMinutes: number;
  viewCount: number;
  likeCount: number;
  status: PostStatus;
  publishedAt: string | null;
  updatedAt: string;
};

export type PostDetail = {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  coverImageUrl: string | null;
  tags: string[];
  author: UserSummary | null;
  readingMinutes: number;
  viewCount: number;
  likeCount: number;
  bookmarkCount: number;
  likedByMe: boolean;
  bookmarkedByMe: boolean;
  status: PostStatus;
  publishedAt: string | null;
  createdAt: string;
  updatedAt: string;
};

export type PageResponse<T> = {
  items: T[];
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
  hasNext: boolean;
};

export type AuthResponse = {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
  user: UserProfile;
};

export type CommentNode = {
  id: string;
  postId: string;
  parentId: string | null;
  content: string;
  author: UserSummary | null;
  createdAt: string;
  updatedAt: string;
  replies: CommentNode[];
};
