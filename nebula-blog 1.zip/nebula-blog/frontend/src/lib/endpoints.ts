import { api, tokenStore } from './api';
import type {
  AuthResponse,
  CommentNode,
  PageResponse,
  PostDetail,
  PostSummary,
  UserProfile,
} from './types';

// ---- Auth ----
export async function register(input: {
  username: string;
  email: string;
  password: string;
  displayName?: string;
}): Promise<AuthResponse> {
  const { data } = await api.post<AuthResponse>('/api/auth/register', input);
  tokenStore.set(data.accessToken, data.refreshToken);
  return data;
}

export async function login(input: { identifier: string; password: string }): Promise<AuthResponse> {
  const { data } = await api.post<AuthResponse>('/api/auth/login', input);
  tokenStore.set(data.accessToken, data.refreshToken);
  return data;
}

export async function logout(): Promise<void> {
  try {
    await api.post('/api/auth/logout');
  } catch {
    // ignore
  } finally {
    tokenStore.clear();
  }
}

// ---- Users ----
export async function fetchMe(): Promise<UserProfile> {
  const { data } = await api.get<UserProfile>('/api/users/me');
  return data;
}

export async function fetchUserByUsername(username: string): Promise<UserProfile> {
  const { data } = await api.get<UserProfile>(`/api/users/${username}`);
  return data;
}

// ---- Posts ----
export async function fetchPosts(params: {
  page?: number;
  size?: number;
  tag?: string;
  search?: string;
} = {}): Promise<PageResponse<PostSummary>> {
  const { data } = await api.get<PageResponse<PostSummary>>('/api/posts', { params });
  return data;
}

export async function fetchPostBySlug(slug: string): Promise<PostDetail> {
  const { data } = await api.get<PostDetail>(`/api/posts/${slug}`);
  return data;
}

export async function createPost(input: {
  title: string;
  excerpt?: string;
  content: string;
  coverImageUrl?: string;
  tags?: string[];
  publish: boolean;
}): Promise<PostDetail> {
  const { data } = await api.post<PostDetail>('/api/posts', input);
  return data;
}

export async function toggleLike(postId: string): Promise<PostDetail> {
  const { data } = await api.post<PostDetail>(`/api/posts/${postId}/like`);
  return data;
}

export async function toggleBookmark(postId: string): Promise<PostDetail> {
  const { data } = await api.post<PostDetail>(`/api/posts/${postId}/bookmark`);
  return data;
}

// ---- Comments ----
export async function fetchComments(postId: string): Promise<CommentNode[]> {
  const { data } = await api.get<CommentNode[]>(`/api/posts/${postId}/comments`);
  return data;
}

export async function createComment(
  postId: string,
  input: { content: string; parentId?: string | null }
): Promise<CommentNode> {
  const { data } = await api.post<CommentNode>(`/api/posts/${postId}/comments`, input);
  return data;
}
