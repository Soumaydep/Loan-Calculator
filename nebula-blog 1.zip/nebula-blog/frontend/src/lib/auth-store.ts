'use client';

import { create } from 'zustand';
import type { UserProfile } from './types';
import { fetchMe, login as apiLogin, logout as apiLogout, register as apiRegister } from './endpoints';
import { tokenStore } from './api';

type AuthState = {
  user: UserProfile | null;
  loading: boolean;
  initialized: boolean;
  init: () => Promise<void>;
  login: (identifier: string, password: string) => Promise<void>;
  register: (input: { username: string; email: string; password: string; displayName?: string }) => Promise<void>;
  logout: () => Promise<void>;
};

export const useAuth = create<AuthState>((set) => ({
  user: null,
  loading: false,
  initialized: false,
  async init() {
    if (!tokenStore.getAccess()) {
      set({ initialized: true });
      return;
    }
    set({ loading: true });
    try {
      const me = await fetchMe();
      set({ user: me, initialized: true, loading: false });
    } catch {
      tokenStore.clear();
      set({ user: null, initialized: true, loading: false });
    }
  },
  async login(identifier, password) {
    set({ loading: true });
    try {
      const res = await apiLogin({ identifier, password });
      set({ user: res.user, loading: false, initialized: true });
    } catch (e) {
      set({ loading: false });
      throw e;
    }
  },
  async register(input) {
    set({ loading: true });
    try {
      const res = await apiRegister(input);
      set({ user: res.user, loading: false, initialized: true });
    } catch (e) {
      set({ loading: false });
      throw e;
    }
  },
  async logout() {
    await apiLogout();
    set({ user: null });
  },
}));
