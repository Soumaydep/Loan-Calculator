import Link from 'next/link';
import { Button } from '@/components/ui/button';

export default function NotFound() {
  return (
    <div className="mx-auto max-w-xl px-6 py-32 text-center">
      <p className="font-display text-7xl gradient-text">404</p>
      <h1 className="mt-4 font-display text-2xl">Lost in the nebula</h1>
      <p className="mt-2 text-ink-dim">We couldn't find the page you were looking for.</p>
      <div className="mt-8">
        <Link href="/">
          <Button>Back to feed</Button>
        </Link>
      </div>
    </div>
  );
}
