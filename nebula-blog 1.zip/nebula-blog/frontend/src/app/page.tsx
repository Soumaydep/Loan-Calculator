import { fetchPosts } from '@/lib/endpoints';
import { PostCard } from '@/components/blog/post-card';
import { HomeHero } from '@/components/blog/home-hero';
import { HeroSceneClient } from '@/components/three/hero-scene-client';

async function getPostsSafe() {
  try {
    return await fetchPosts({ size: 12 });
  } catch {
    return { items: [], page: 0, size: 12, totalElements: 0, totalPages: 0, hasNext: false };
  }
}

export default async function HomePage({
  searchParams,
}: {
  searchParams: Promise<{ tag?: string; search?: string }>;
}) {
  const sp = await searchParams;
  let initialPosts;
  if (sp.tag || sp.search) {
    try {
      initialPosts = await fetchPosts({ size: 24, tag: sp.tag, search: sp.search });
    } catch {
      initialPosts = await getPostsSafe();
    }
  } else {
    initialPosts = await getPostsSafe();
  }

  const filtering = Boolean(sp.tag || sp.search);

  return (
    <>
      {!filtering && (
        <section className="relative">
          <div className="absolute inset-0 -z-10">
            <HeroSceneClient />
          </div>
          <HomeHero />
        </section>
      )}

      <section className="mx-auto max-w-7xl px-6 pb-24">
        <div className="flex items-end justify-between mb-8">
          <div>
            <h2 className="font-display text-3xl tracking-tight">
              {filtering ? (sp.search ? `Results for “${sp.search}”` : `Posts tagged #${sp.tag}`) : 'Latest stories'}
            </h2>
            <p className="text-ink-dim mt-1">
              {initialPosts.totalElements} post{initialPosts.totalElements === 1 ? '' : 's'}
            </p>
          </div>
        </div>

        {initialPosts.items.length === 0 ? (
          <div className="glass rounded-2xl p-10 text-center">
            <p className="text-ink-dim">
              No posts yet. {filtering ? 'Try clearing the filter.' : 'Be the first to publish.'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {initialPosts.items.map((p, i) => (
              <PostCard key={p.id} post={p} priority={i < 3} />
            ))}
          </div>
        )}
      </section>
    </>
  );
}
