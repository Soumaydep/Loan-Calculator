'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { useAuth } from '@/lib/auth-store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { MarkdownContent } from '@/components/blog/markdown-content';
import { createPost } from '@/lib/endpoints';

export default function EditorPage() {
  const router = useRouter();
  const user = useAuth((s) => s.user);
  const initialized = useAuth((s) => s.initialized);

  const [title, setTitle] = useState('');
  const [excerpt, setExcerpt] = useState('');
  const [coverImageUrl, setCoverImageUrl] = useState('');
  const [tagsInput, setTagsInput] = useState('');
  const [content, setContent] = useState('# Hello, world\n\nWrite something amazing.');
  const [tab, setTab] = useState<'write' | 'preview'>('write');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (initialized && !user) router.replace('/login');
  }, [initialized, user, router]);

  if (!initialized || !user) {
    return <div className="mx-auto max-w-4xl px-6 py-20 text-ink-dim">Loading…</div>;
  }

  async function submit(publish: boolean) {
    setSubmitting(true);
    setError(null);
    try {
      const tags = tagsInput
        .split(',')
        .map((t) => t.trim().toLowerCase())
        .filter(Boolean);
      const post = await createPost({
        title,
        excerpt: excerpt || undefined,
        coverImageUrl: coverImageUrl || undefined,
        tags,
        content,
        publish,
      });
      router.push(publish ? `/p/${post.slug}` : `/u/${user!.username}`);
    } catch (err: unknown) {
      const data = (err as { response?: { data?: { message?: string; details?: string[] } } }).response?.data;
      setError(data?.details?.[0] ?? data?.message ?? 'Failed to save');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="mx-auto max-w-5xl px-6 py-12">
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex items-center justify-between mb-6"
      >
        <h1 className="font-display text-3xl">New post</h1>
        <div className="flex gap-2">
          <Button variant="subtle" disabled={submitting} onClick={() => submit(false)}>
            Save draft
          </Button>
          <Button disabled={submitting || title.trim().length === 0 || content.trim().length === 0} onClick={() => submit(true)}>
            {submitting ? 'Publishing…' : 'Publish'}
          </Button>
        </div>
      </motion.div>

      <div className="glass rounded-2xl p-6 flex flex-col gap-4">
        <Input
          label="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="An unforgettable headline"
          maxLength={200}
        />
        <Input
          label="Cover image URL (optional)"
          value={coverImageUrl}
          onChange={(e) => setCoverImageUrl(e.target.value)}
          placeholder="https://…"
        />
        <Input
          label="Tags (comma separated)"
          value={tagsInput}
          onChange={(e) => setTagsInput(e.target.value)}
          placeholder="design, react, 3d"
        />
        <Textarea
          label="Excerpt (optional)"
          value={excerpt}
          onChange={(e) => setExcerpt(e.target.value)}
          placeholder="A teaser shown on cards and previews."
          maxLength={500}
          className="min-h-[80px]"
        />

        <div className="flex items-center gap-1 mt-2">
          <TabBtn active={tab === 'write'} onClick={() => setTab('write')}>Write</TabBtn>
          <TabBtn active={tab === 'preview'} onClick={() => setTab('preview')}>Preview</TabBtn>
        </div>

        {tab === 'write' ? (
          <Textarea
            label="Content (markdown)"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="min-h-[480px] font-mono text-sm"
          />
        ) : (
          <div className="min-h-[480px] p-4 rounded-xl bg-white/[0.02] border border-white/10">
            <MarkdownContent content={content} />
          </div>
        )}

        {error && <p className="text-sm text-rose-400">{error}</p>}
      </div>
    </div>
  );
}

function TabBtn({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={
        'px-3 h-8 rounded-lg text-sm transition-colors ' +
        (active ? 'bg-white/[0.08] text-white' : 'text-ink-dim hover:text-ink hover:bg-white/[0.04]')
      }
    >
      {children}
    </button>
  );
}
