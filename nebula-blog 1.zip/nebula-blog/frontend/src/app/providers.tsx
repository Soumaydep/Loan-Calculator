'use client';

import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useState, type ReactNode, useEffect } from 'react';
import { useAuth } from '@/lib/auth-store';

export function Providers({ children }: { children: ReactNode }) {
  const [client] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: { staleTime: 30_000, refetchOnWindowFocus: false, retry: 1 },
        },
      })
  );

  const init = useAuth((s) => s.init);
  useEffect(() => {
    init();
  }, [init]);

  return <QueryClientProvider client={client}>{children}</QueryClientProvider>;
}
