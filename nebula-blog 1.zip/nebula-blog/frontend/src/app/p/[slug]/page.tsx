import { notFound } from 'next/navigation';
import type { Metadata } from 'next';
import { fetchPostBySlug } from '@/lib/endpoints';
import { MarkdownContent } from '@/components/blog/markdown-content';
import { ReadingProgress } from '@/components/blog/reading-progress';
import { PostInteractionBar } from '@/components/blog/post-interaction-bar';
import { CommentsThread } from '@/components/blog/comments-thread';
import { TagPill } from '@/components/ui/tag-pill';
import { AmbientSceneClient } from '@/components/three/ambient-scene-client';

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  try {
    const post = await fetchPostBySlug(slug);
    return {
      title: post.title,
      description: post.excerpt,
      openGraph: {
        title: post.title,
        description: post.excerpt,
        images: post.coverImageUrl ? [post.coverImageUrl] : undefined,
        type: 'article',
        authors: post.author ? [post.author.displayName] : undefined,
      },
    };
  } catch {
    return { title: 'Post not found' };
  }
}

export default async function PostPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  let post: Awaited<ReturnType<typeof fetchPostBySlug>>;
  try {
    post = await fetchPostBySlug(slug);
  } catch {
    notFound();
  }

  const author = post.author;
  const initials = author?.displayName?.[0]?.toUpperCase() ?? '?';
  const publishedDate = post.publishedAt ? new Date(post.publishedAt).toLocaleDateString(undefined, {
    year: 'numeric', month: 'long', day: 'numeric',
  }) : null;

  return (
    <>
      <ReadingProgress />
      <AmbientSceneClient />

      <article className="mx-auto max-w-3xl px-6 pt-16 pb-32">
        {/* Header */}
        <header className="mb-10">
          <div className="flex flex-wrap gap-2 mb-5">
            {post.tags.map((t) => (
              <TagPill key={t} tag={t} />
            ))}
          </div>
          <h1 className="font-display text-4xl md:text-5xl leading-tight tracking-tight">
            {post.title}
          </h1>
          {post.excerpt && <p className="mt-5 text-lg text-ink-dim leading-relaxed">{post.excerpt}</p>}

          <div className="mt-8 flex items-center gap-3">
            {author?.avatarUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={author.avatarUrl} alt="" className="w-10 h-10 rounded-full" />
            ) : (
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-accent-electric to-accent-neon grid place-items-center text-sm font-semibold">
                {initials}
              </div>
            )}
            <div className="text-sm">
              <p className="text-ink">{author?.displayName ?? 'Unknown'}</p>
              <p className="text-ink-faint">
                {publishedDate} · {post.readingMinutes} min read · {post.viewCount} views
              </p>
            </div>
          </div>
        </header>

        {/* Cover */}
        {post.coverImageUrl && (
          <div className="mb-12 rounded-2xl overflow-hidden border border-white/10">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={post.coverImageUrl} alt="" className="w-full h-auto" />
          </div>
        )}

        {/* Body */}
        <MarkdownContent content={post.content} />

        {/* Floating interaction bar */}
        <div className="mt-14 flex justify-center">
          <PostInteractionBar post={post} />
        </div>

        <CommentsThread postId={post.id} />
      </article>
    </>
  );
}
