export default function Loading() {
  return (
    <div className="mx-auto max-w-7xl px-6 py-24">
      <div className="h-10 w-1/3 rounded-lg bg-white/[0.04] animate-pulse" />
      <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="glass rounded-2xl overflow-hidden">
            <div className="aspect-[16/9] bg-white/[0.03] animate-pulse" />
            <div className="p-5 flex flex-col gap-3">
              <div className="h-4 w-3/4 rounded bg-white/[0.04] animate-pulse" />
              <div className="h-3 w-full rounded bg-white/[0.03] animate-pulse" />
              <div className="h-3 w-5/6 rounded bg-white/[0.03] animate-pulse" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
