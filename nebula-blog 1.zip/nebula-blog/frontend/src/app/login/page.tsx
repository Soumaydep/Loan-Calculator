'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/lib/auth-store';

export default function LoginPage() {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();
  const login = useAuth((s) => s.login);
  const loading = useAuth((s) => s.loading);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      await login(identifier, password);
      router.push('/');
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { message?: string } } }).response?.data?.message;
      setError(msg ?? 'Sign in failed');
    }
  }

  return (
    <div className="mx-auto max-w-md px-6 py-20">
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        className="glass-strong rounded-3xl p-8"
      >
        <h1 className="font-display text-3xl">Welcome back</h1>
        <p className="text-ink-dim mt-1">Sign in to continue to Nebula.</p>

        <form onSubmit={onSubmit} className="mt-8 flex flex-col gap-4">
          <Input
            label="Email or username"
            name="identifier"
            autoComplete="username"
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
            required
          />
          <Input
            label="Password"
            type="password"
            name="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          {error && <p className="text-sm text-rose-400">{error}</p>}

          <Button type="submit" disabled={loading} className="mt-2">
            {loading ? 'Signing in…' : 'Sign in'}
          </Button>

          {/* EXTENSION POINT: OAuth buttons. Wire to /oauth2/authorization/google etc. */}
          <div className="text-xs text-ink-faint text-center mt-1">
            OAuth providers (Google / GitHub) — extension point.
          </div>
        </form>

        <p className="mt-6 text-sm text-ink-dim text-center">
          New here?{' '}
          <Link href="/register" className="text-accent-electric hover:underline">
            Create an account
          </Link>
        </p>

        <p className="mt-6 text-xs text-ink-faint text-center">
          Demo: <code className="text-ink-dim">nova@nebula.dev</code> / <code className="text-ink-dim">password123</code>
        </p>
      </motion.div>
    </div>
  );
}
