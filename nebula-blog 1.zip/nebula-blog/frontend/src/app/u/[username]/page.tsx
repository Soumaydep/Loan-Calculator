import { notFound } from 'next/navigation';
import { fetchUserByUsername, fetchPosts } from '@/lib/endpoints';
import { PostCard } from '@/components/blog/post-card';
import type { Metadata } from 'next';

export async function generateMetadata({
  params,
}: {
  params: Promise<{ username: string }>;
}): Promise<Metadata> {
  const { username } = await params;
  try {
    const user = await fetchUserByUsername(username);
    return { title: `${user.displayName} (@${user.username})` };
  } catch {
    return { title: 'User not found' };
  }
}

export default async function UserPage({ params }: { params: Promise<{ username: string }> }) {
  const { username } = await params;
  let user: Awaited<ReturnType<typeof fetchUserByUsername>>;
  try {
    user = await fetchUserByUsername(username);
  } catch {
    notFound();
  }

  // The public posts endpoint doesn't filter by author, so we use the by-author endpoint.
  // For the starter we just hit /api/posts and filter client-side; production should use a dedicated query.
  let posts = { items: [] as Awaited<ReturnType<typeof fetchPosts>>['items'] };
  try {
    const all = await fetchPosts({ size: 50 });
    posts = { items: all.items.filter((p) => p.author?.id === user.id) };
  } catch {
    /* ignore */
  }

  const initials = user.displayName?.[0]?.toUpperCase() ?? '?';

  return (
    <div className="mx-auto max-w-6xl px-6 pt-12 pb-24">
      <header className="glass-strong rounded-3xl p-8 md:p-10 relative overflow-hidden">
        <div aria-hidden className="absolute inset-0 bg-mesh-aurora opacity-60" />
        <div className="relative flex flex-col sm:flex-row gap-6 items-start sm:items-center">
          {user.avatarUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={user.avatarUrl} alt="" className="w-24 h-24 rounded-2xl border border-white/15" />
          ) : (
            <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-accent-electric to-accent-neon grid place-items-center text-3xl font-semibold">
              {initials}
            </div>
          )}
          <div className="flex-1">
            <h1 className="font-display text-3xl md:text-4xl">{user.displayName}</h1>
            <p className="text-ink-dim">@{user.username}</p>
            {user.bio && <p className="mt-3 text-ink-dim leading-relaxed max-w-prose">{user.bio}</p>}
            <div className="mt-4 flex gap-6 text-sm">
              <span><span className="text-ink font-medium">{user.followerCount}</span> <span className="text-ink-faint">followers</span></span>
              <span><span className="text-ink font-medium">{user.followingCount}</span> <span className="text-ink-faint">following</span></span>
            </div>
          </div>
        </div>
      </header>

      <section className="mt-12">
        <h2 className="font-display text-2xl mb-6">Posts</h2>
        {posts.items.length === 0 ? (
          <p className="text-ink-faint">No posts yet.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {posts.items.map((p) => (
              <PostCard key={p.id} post={p} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
