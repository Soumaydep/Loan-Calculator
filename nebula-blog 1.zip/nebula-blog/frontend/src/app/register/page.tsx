'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/lib/auth-store';

export default function RegisterPage() {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [error, setError] = useState<string | null>(null);

  const router = useRouter();
  const register = useAuth((s) => s.register);
  const loading = useAuth((s) => s.loading);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      await register({ username, email, password, displayName: displayName || undefined });
      router.push('/');
    } catch (err: unknown) {
      const data = (err as { response?: { data?: { message?: string; details?: string[] } } }).response?.data;
      setError(data?.details?.[0] ?? data?.message ?? 'Sign up failed');
    }
  }

  return (
    <div className="mx-auto max-w-md px-6 py-20">
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        className="glass-strong rounded-3xl p-8"
      >
        <h1 className="font-display text-3xl">Create your account</h1>
        <p className="text-ink-dim mt-1">Start publishing in under a minute.</p>

        <form onSubmit={onSubmit} className="mt-8 flex flex-col gap-4">
          <Input
            label="Username"
            name="username"
            autoComplete="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            minLength={3}
            maxLength={24}
            pattern="[A-Za-z0-9_]+"
            required
          />
          <Input
            label="Display name (optional)"
            name="displayName"
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
          />
          <Input
            label="Email"
            type="email"
            name="email"
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <Input
            label="Password"
            type="password"
            name="password"
            autoComplete="new-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            minLength={8}
            required
          />
          {error && <p className="text-sm text-rose-400">{error}</p>}

          <Button type="submit" disabled={loading} className="mt-2">
            {loading ? 'Creating account…' : 'Create account'}
          </Button>
        </form>

        <p className="mt-6 text-sm text-ink-dim text-center">
          Already have an account?{' '}
          <Link href="/login" className="text-accent-electric hover:underline">
            Sign in
          </Link>
        </p>
      </motion.div>
    </div>
  );
}
