import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        bg: {
          DEFAULT: '#07060d',
          soft: '#0d0c1a',
          card: 'rgba(255,255,255,0.04)',
        },
        ink: {
          DEFAULT: '#e8e8f5',
          dim: '#9b9bb6',
          faint: '#6b6b86',
        },
        accent: {
          electric: '#5b8cff',
          neon: '#a06bff',
          cyan: '#39d6ff',
          aurora: '#5bffb1',
          amber: '#ffb45a',
          pink: '#ff7ad6',
        },
      },
      fontFamily: {
        sans: ['var(--font-inter)', 'ui-sans-serif', 'system-ui'],
        display: ['var(--font-space)', 'ui-sans-serif', 'system-ui'],
      },
      backgroundImage: {
        'mesh-aurora':
          'radial-gradient(at 20% 10%, rgba(91,140,255,0.25) 0px, transparent 50%), radial-gradient(at 80% 0%, rgba(160,107,255,0.22) 0px, transparent 50%), radial-gradient(at 60% 80%, rgba(57,214,255,0.18) 0px, transparent 50%)',
      },
      boxShadow: {
        glow: '0 0 0 1px rgba(255,255,255,0.06), 0 20px 60px -20px rgba(91,140,255,0.35)',
        'glow-lg': '0 0 0 1px rgba(255,255,255,0.08), 0 30px 80px -20px rgba(160,107,255,0.45)',
      },
      animation: {
        'spin-slow': 'spin 24s linear infinite',
        float: 'float 8s ease-in-out infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-10px)' },
        },
      },
    },
  },
  plugins: [],
};

export default config;
