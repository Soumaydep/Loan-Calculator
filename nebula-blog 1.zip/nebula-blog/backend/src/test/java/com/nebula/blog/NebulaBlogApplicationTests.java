package com.nebula.blog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("test")
class NebulaBlogApplicationTests {

    @Test
    void contextLoads() {
        // Smoke test: Spring context boots without errors using embedded MongoDB.
    }
}
