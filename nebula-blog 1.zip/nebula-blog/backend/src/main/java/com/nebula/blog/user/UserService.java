package com.nebula.blog.user;

import com.nebula.blog.exception.NotFoundException;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public User getById(String id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("User not found: " + id));
    }

    public User getByUsername(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new NotFoundException("User not found: " + username));
    }

    public User updateProfile(String userId, UserDtos.UpdateProfileRequest req) {
        User user = getById(userId);
        if (req.displayName() != null) user.setDisplayName(req.displayName());
        if (req.bio() != null) user.setBio(req.bio());
        if (req.avatarUrl() != null) user.setAvatarUrl(req.avatarUrl());
        return userRepository.save(user);
    }

    public void follow(String currentUserId, String targetUserId) {
        if (currentUserId.equals(targetUserId)) {
            throw new IllegalArgumentException("Cannot follow yourself");
        }
        User me = getById(currentUserId);
        User target = getById(targetUserId);
        me.getFollowing().add(targetUserId);
        target.getFollowers().add(currentUserId);
        userRepository.save(me);
        userRepository.save(target);
    }

    public void unfollow(String currentUserId, String targetUserId) {
        User me = getById(currentUserId);
        User target = getById(targetUserId);
        me.getFollowing().remove(targetUserId);
        target.getFollowers().remove(currentUserId);
        userRepository.save(me);
        userRepository.save(target);
    }
}
