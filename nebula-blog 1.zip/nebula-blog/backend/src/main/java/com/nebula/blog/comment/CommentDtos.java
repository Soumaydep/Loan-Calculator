package com.nebula.blog.comment;

import com.nebula.blog.user.UserDtos;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.time.Instant;
import java.util.List;

public class CommentDtos {

    public record CreateCommentRequest(
            @NotBlank @Size(max = 2000) String content,
            String parentId
    ) {}

    public record CommentNode(
            String id,
            String postId,
            String parentId,
            String content,
            UserDtos.UserSummary author,
            Instant createdAt,
            Instant updatedAt,
            List<CommentNode> replies
    ) {}
}
