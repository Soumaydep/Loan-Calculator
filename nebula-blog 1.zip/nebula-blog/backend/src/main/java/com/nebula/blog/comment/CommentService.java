package com.nebula.blog.comment;

import com.nebula.blog.exception.ForbiddenException;
import com.nebula.blog.exception.NotFoundException;
import com.nebula.blog.post.PostRepository;
import com.nebula.blog.user.User;
import com.nebula.blog.user.UserDtos;
import com.nebula.blog.user.UserRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CommentService {

    private final CommentRepository commentRepository;
    private final PostRepository postRepository;
    private final UserRepository userRepository;

    public CommentService(CommentRepository commentRepository,
                          PostRepository postRepository,
                          UserRepository userRepository) {
        this.commentRepository = commentRepository;
        this.postRepository = postRepository;
        this.userRepository = userRepository;
    }

    public CommentDtos.CommentNode create(String postId, String authorId, CommentDtos.CreateCommentRequest req) {
        if (!postRepository.existsById(postId)) {
            throw new NotFoundException("Post not found");
        }
        if (req.parentId() != null) {
            Comment parent = commentRepository.findById(req.parentId())
                    .orElseThrow(() -> new NotFoundException("Parent comment not found"));
            if (!parent.getPostId().equals(postId)) {
                throw new IllegalArgumentException("Parent comment belongs to a different post");
            }
        }
        Comment c = new Comment();
        c.setPostId(postId);
        c.setAuthorId(authorId);
        c.setContent(req.content());
        c.setParentId(req.parentId());
        Comment saved = commentRepository.save(c);

        User author = userRepository.findById(authorId).orElse(null);
        return new CommentDtos.CommentNode(
                saved.getId(), saved.getPostId(), saved.getParentId(), saved.getContent(),
                author == null ? null : UserDtos.UserSummary.from(author),
                saved.getCreatedAt(), saved.getUpdatedAt(),
                List.of()
        );
    }

    public void delete(String commentId, String userId) {
        Comment c = commentRepository.findById(commentId)
                .orElseThrow(() -> new NotFoundException("Comment not found"));
        if (!c.getAuthorId().equals(userId)) {
            throw new ForbiddenException("You cannot delete this comment");
        }
        commentRepository.delete(c);
    }

    public List<CommentDtos.CommentNode> listForPost(String postId) {
        List<Comment> all = commentRepository.findByPostId(postId, Sort.by(Sort.Direction.ASC, "createdAt"));
        if (all.isEmpty()) return List.of();

        List<String> authorIds = all.stream().map(Comment::getAuthorId).distinct().toList();
        Map<String, User> authors = new HashMap<>();
        userRepository.findAllById(authorIds).forEach(u -> authors.put(u.getId(), u));

        // Build nodes keyed by id
        Map<String, CommentDtos.CommentNode> nodes = new HashMap<>();
        Map<String, List<CommentDtos.CommentNode>> childBuckets = new HashMap<>();
        for (Comment c : all) {
            User a = authors.get(c.getAuthorId());
            List<CommentDtos.CommentNode> replies = new ArrayList<>();
            CommentDtos.CommentNode node = new CommentDtos.CommentNode(
                    c.getId(), c.getPostId(), c.getParentId(), c.getContent(),
                    a == null ? null : UserDtos.UserSummary.from(a),
                    c.getCreatedAt(), c.getUpdatedAt(),
                    replies
            );
            nodes.put(c.getId(), node);
            childBuckets.put(c.getId(), replies);
        }

        // Wire replies to their parents
        List<CommentDtos.CommentNode> roots = new ArrayList<>();
        for (Comment c : all) {
            CommentDtos.CommentNode node = nodes.get(c.getId());
            if (c.getParentId() == null || !nodes.containsKey(c.getParentId())) {
                roots.add(node);
            } else {
                childBuckets.get(c.getParentId()).add(node);
            }
        }
        return roots;
    }
}
