package com.nebula.blog.post;

import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Pattern;

final class PostUtils {

    private static final Pattern NON_LATIN = Pattern.compile("[^\\w-]");
    private static final Pattern WHITESPACE = Pattern.compile("[\\s]+");

    private PostUtils() {}

    static String slugify(String input) {
        if (input == null || input.isBlank()) return "";
        String nowhitespace = WHITESPACE.matcher(input.trim()).replaceAll("-");
        String normalized = Normalizer.normalize(nowhitespace, Normalizer.Form.NFD);
        String slug = NON_LATIN.matcher(normalized).replaceAll("");
        return slug.toLowerCase(Locale.ENGLISH).replaceAll("-+", "-").replaceAll("^-|-$", "");
    }

    static int estimateReadingMinutes(String markdown) {
        if (markdown == null || markdown.isBlank()) return 1;
        // ~200 wpm average reading speed
        int words = markdown.trim().split("\\s+").length;
        return Math.max(1, (int) Math.ceil(words / 200.0));
    }
}
