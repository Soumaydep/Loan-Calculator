package com.nebula.blog.user;

import jakarta.validation.constraints.Size;

import java.time.Instant;
import java.util.Set;

public class UserDtos {

    public record UserSummary(
            String id,
            String username,
            String displayName,
            String avatarUrl
    ) {
        public static UserSummary from(User u) {
            return new UserSummary(u.getId(), u.getUsername(), u.getDisplayName(), u.getAvatarUrl());
        }
    }

    public record UserProfile(
            String id,
            String username,
            String email,
            String displayName,
            String avatarUrl,
            String bio,
            int followerCount,
            int followingCount,
            Set<String> roles,
            Instant createdAt
    ) {
        public static UserProfile from(User u) {
            return new UserProfile(
                    u.getId(), u.getUsername(), u.getEmail(),
                    u.getDisplayName(), u.getAvatarUrl(), u.getBio(),
                    u.getFollowers().size(), u.getFollowing().size(),
                    u.getRoles(), u.getCreatedAt()
            );
        }
    }

    public record UpdateProfileRequest(
            @Size(max = 80) String displayName,
            @Size(max = 280) String bio,
            @Size(max = 500) String avatarUrl
    ) {}
}
