package com.nebula.blog.config;

import com.nebula.blog.post.Post;
import com.nebula.blog.post.PostRepository;
import com.nebula.blog.user.User;
import com.nebula.blog.user.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.Instant;
import java.util.List;
import java.util.Set;

@Configuration
@Profile("!test")
public class DataSeeder {

    private static final Logger log = LoggerFactory.getLogger(DataSeeder.class);

    @Bean
    CommandLineRunner seed(UserRepository users, PostRepository posts, PasswordEncoder encoder) {
        return args -> {
            if (users.count() > 0) {
                log.info("Database already seeded; skipping.");
                return;
            }

            User demo = new User();
            demo.setUsername("nova");
            demo.setEmail("nova@nebula.dev");
            demo.setDisplayName("Nova Carter");
            demo.setBio("Frontend engineer obsessed with shaders and motion.");
            demo.setAvatarUrl("https://api.dicebear.com/9.x/glass/svg?seed=nova");
            demo.setPasswordHash(encoder.encode("password123"));
            demo.setRoles(Set.of("ROLE_USER"));
            users.save(demo);

            User admin = new User();
            admin.setUsername("orion");
            admin.setEmail("orion@nebula.dev");
            admin.setDisplayName("Orion Vega");
            admin.setBio("Backend & systems. Coffee-powered.");
            admin.setAvatarUrl("https://api.dicebear.com/9.x/glass/svg?seed=orion");
            admin.setPasswordHash(encoder.encode("password123"));
            admin.setRoles(Set.of("ROLE_USER", "ROLE_ADMIN"));
            users.save(admin);

            posts.save(buildPost(
                    demo.getId(),
                    "Designing for Depth: A Practical Guide to 3D on the Web",
                    "designing-for-depth-3d-on-the-web",
                    "How to use React Three Fiber, Drei, and post-processing to add depth without tanking performance.",
                    """
                    # Designing for Depth

                    Three.js opens a door. **React Three Fiber** turns that door into a hallway you can actually walk down without losing your mind.

                    ## Why depth matters
                    Flat interfaces are efficient. They are also forgettable. A small amount of motion-driven depth — parallax layers, ambient lighting, gentle camera drift — gives your product a felt quality that copy cannot match.

                    ## The three rules
                    1. Never let 3D block content
                    2. Respect `prefers-reduced-motion`
                    3. Keep frame budgets honest (sub-2ms on the GPU for ambient scenes)

                    ```tsx
                    function Ambient() {
                      return (
                        <Canvas dpr={[1, 1.5]} gl={{ antialias: true }}>
                          <ambientLight intensity={0.6} />
                          <Stars radius={120} depth={50} count={3000} factor={4} fade />
                        </Canvas>
                      )
                    }
                    ```
                    """,
                    List.of("3d", "design", "react"),
                    "https://images.unsplash.com/photo-1635776062127-d379bfcba9f8?w=1600"
            ));

            posts.save(buildPost(
                    demo.getId(),
                    "Framer Motion Patterns I Use in Every Project",
                    "framer-motion-patterns",
                    "Layout animations, shared element transitions, and the layoutId trick that everyone should know.",
                    """
                    # Framer Motion Patterns

                    A small pattern library that has paid for itself a hundred times over.

                    ## Shared element transitions
                    Use `layoutId` to make two elements feel like one.

                    ## Stagger reveal
                    Parent variants + `staggerChildren` is the cheapest way to make a list feel premium.

                    ## Inertia, not duration
                    Spring physics > timing curves for almost everything UI.
                    """,
                    List.of("framer-motion", "react", "ux"),
                    "https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?w=1600"
            ));

            posts.save(buildPost(
                    admin.getId(),
                    "A Pragmatic JWT Setup for Spring Boot 3",
                    "pragmatic-jwt-spring-boot-3",
                    "Stateless auth without the foot-guns: rotation, refresh tokens, and where to draw the line.",
                    """
                    # A Pragmatic JWT Setup

                    JWTs are not magic. They are signed JSON. Treat them that way.

                    ## Two tokens, two TTLs
                    A short-lived access token and a longer-lived refresh token. Don't put both in the same cookie.

                    ## What I wouldn't do
                    - Store secrets in `application.properties` (use env vars)
                    - Skip the `typ` claim — you'll regret it the first time someone passes a refresh token where an access token belongs

                    ## The boring win
                    A blacklist for refresh tokens in Redis closes the logout loop.
                    """,
                    List.of("spring-boot", "auth", "backend"),
                    "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=1600"
            ));

            log.info("Seeded {} users and {} posts.", users.count(), posts.count());
        };
    }

    private Post buildPost(String authorId, String title, String slug, String excerpt,
                           String content, List<String> tags, String cover) {
        Post p = new Post();
        p.setAuthorId(authorId);
        p.setTitle(title);
        p.setSlug(slug);
        p.setExcerpt(excerpt);
        p.setContent(content);
        p.setTags(tags);
        p.setCoverImageUrl(cover);
        p.setStatus(Post.Status.PUBLISHED);
        p.setPublishedAt(Instant.now());
        int words = content.trim().split("\\s+").length;
        p.setReadingMinutes(Math.max(1, (int) Math.ceil(words / 200.0)));
        return p;
    }
}
