package com.nebula.blog.post;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.index.TextIndexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Document(collection = "posts")
public class Post {

    public enum Status { DRAFT, PUBLISHED }

    @Id
    private String id;

    @Indexed(unique = true)
    private String slug;

    @TextIndexed(weight = 3)
    private String title;

    @TextIndexed(weight = 1)
    private String excerpt;

    @TextIndexed(weight = 2)
    private String content; // markdown

    private String coverImageUrl;

    @Indexed
    private List<String> tags = List.of();

    @Indexed
    private String authorId;

    @Indexed
    private Status status = Status.DRAFT;

    private long viewCount;

    private Set<String> likedBy = new HashSet<>();
    private Set<String> bookmarkedBy = new HashSet<>();

    private Integer readingMinutes;

    @Indexed
    private Instant publishedAt;

    @CreatedDate
    private Instant createdAt;

    @LastModifiedDate
    private Instant updatedAt;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getSlug() { return slug; }
    public void setSlug(String slug) { this.slug = slug; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getExcerpt() { return excerpt; }
    public void setExcerpt(String excerpt) { this.excerpt = excerpt; }
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    public String getCoverImageUrl() { return coverImageUrl; }
    public void setCoverImageUrl(String coverImageUrl) { this.coverImageUrl = coverImageUrl; }
    public List<String> getTags() { return tags; }
    public void setTags(List<String> tags) { this.tags = tags; }
    public String getAuthorId() { return authorId; }
    public void setAuthorId(String authorId) { this.authorId = authorId; }
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }
    public long getViewCount() { return viewCount; }
    public void setViewCount(long viewCount) { this.viewCount = viewCount; }
    public Set<String> getLikedBy() { return likedBy; }
    public void setLikedBy(Set<String> likedBy) { this.likedBy = likedBy; }
    public Set<String> getBookmarkedBy() { return bookmarkedBy; }
    public void setBookmarkedBy(Set<String> bookmarkedBy) { this.bookmarkedBy = bookmarkedBy; }
    public Integer getReadingMinutes() { return readingMinutes; }
    public void setReadingMinutes(Integer readingMinutes) { this.readingMinutes = readingMinutes; }
    public Instant getPublishedAt() { return publishedAt; }
    public void setPublishedAt(Instant publishedAt) { this.publishedAt = publishedAt; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
}
