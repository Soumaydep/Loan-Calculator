package com.nebula.blog.post;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.Optional;

public interface PostRepository extends MongoRepository<Post, String> {

    Optional<Post> findBySlug(String slug);

    boolean existsBySlug(String slug);

    Page<Post> findByStatus(Post.Status status, Pageable pageable);

    Page<Post> findByStatusAndTagsIn(Post.Status status, java.util.List<String> tags, Pageable pageable);

    Page<Post> findByAuthorId(String authorId, Pageable pageable);

    Page<Post> findByAuthorIdAndStatus(String authorId, Post.Status status, Pageable pageable);

    @Query("{ $text: { $search: ?0 }, status: ?1 }")
    Page<Post> searchPublished(String text, Post.Status status, Pageable pageable);
}
