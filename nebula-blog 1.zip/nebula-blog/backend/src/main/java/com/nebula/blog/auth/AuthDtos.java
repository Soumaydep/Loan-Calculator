package com.nebula.blog.auth;

import com.nebula.blog.user.UserDtos;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class AuthDtos {

    public record RegisterRequest(
            @NotBlank @Size(min = 3, max = 24)
            @Pattern(regexp = "^[a-zA-Z0-9_]+$", message = "Username may only contain letters, digits, and underscores")
            String username,

            @NotBlank @Email @Size(max = 120)
            String email,

            @NotBlank @Size(min = 8, max = 100)
            String password,

            @Size(max = 80)
            String displayName
    ) {}

    public record LoginRequest(
            @NotBlank String identifier,
            @NotBlank String password
    ) {}

    public record RefreshRequest(@NotBlank String refreshToken) {}

    public record AuthResponse(
            String accessToken,
            String refreshToken,
            long expiresIn,
            UserDtos.UserProfile user
    ) {}
}
