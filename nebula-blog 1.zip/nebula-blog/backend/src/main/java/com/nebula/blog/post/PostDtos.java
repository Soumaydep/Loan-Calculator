package com.nebula.blog.post;

import com.nebula.blog.user.UserDtos;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.time.Instant;
import java.util.List;

public class PostDtos {

    public record CreatePostRequest(
            @NotBlank @Size(max = 200) String title,
            @Size(max = 500) String excerpt,
            @NotBlank String content,
            @Size(max = 500) String coverImageUrl,
            List<@Size(max = 30) String> tags,
            boolean publish
    ) {}

    public record UpdatePostRequest(
            @Size(max = 200) String title,
            @Size(max = 500) String excerpt,
            String content,
            @Size(max = 500) String coverImageUrl,
            List<@Size(max = 30) String> tags,
            Post.Status status
    ) {}

    public record PostSummary(
            String id,
            String slug,
            String title,
            String excerpt,
            String coverImageUrl,
            List<String> tags,
            UserDtos.UserSummary author,
            int readingMinutes,
            long viewCount,
            int likeCount,
            Post.Status status,
            Instant publishedAt,
            Instant updatedAt
    ) {}

    public record PostDetail(
            String id,
            String slug,
            String title,
            String excerpt,
            String content,
            String coverImageUrl,
            List<String> tags,
            UserDtos.UserSummary author,
            int readingMinutes,
            long viewCount,
            int likeCount,
            int bookmarkCount,
            boolean likedByMe,
            boolean bookmarkedByMe,
            Post.Status status,
            Instant publishedAt,
            Instant createdAt,
            Instant updatedAt
    ) {}
}
