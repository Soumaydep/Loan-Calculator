package com.nebula.blog.comment;

import com.nebula.blog.security.CurrentUser;
import com.nebula.blog.security.UserPrincipal;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class CommentController {

    private final CommentService commentService;

    public CommentController(CommentService commentService) {
        this.commentService = commentService;
    }

    @GetMapping("/posts/{postId}/comments")
    public List<CommentDtos.CommentNode> list(@PathVariable String postId) {
        return commentService.listForPost(postId);
    }

    @PostMapping("/posts/{postId}/comments")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<CommentDtos.CommentNode> create(
            @CurrentUser UserPrincipal principal,
            @PathVariable String postId,
            @Valid @RequestBody CommentDtos.CreateCommentRequest req) {
        return ResponseEntity.status(201).body(commentService.create(postId, principal.getId(), req));
    }

    @DeleteMapping("/comments/{commentId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Void> delete(
            @CurrentUser UserPrincipal principal,
            @PathVariable String commentId) {
        commentService.delete(commentId, principal.getId());
        return ResponseEntity.noContent().build();
    }
}
