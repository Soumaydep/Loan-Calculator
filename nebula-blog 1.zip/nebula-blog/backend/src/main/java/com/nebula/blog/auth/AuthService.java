package com.nebula.blog.auth;

import com.nebula.blog.exception.ConflictException;
import com.nebula.blog.exception.NotFoundException;
import com.nebula.blog.security.JwtService;
import com.nebula.blog.user.User;
import com.nebula.blog.user.UserDtos;
import com.nebula.blog.user.UserRepository;
import io.jsonwebtoken.JwtException;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authManager;
    private final JwtService jwtService;

    public AuthService(UserRepository userRepository,
                       PasswordEncoder passwordEncoder,
                       AuthenticationManager authManager,
                       JwtService jwtService) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.authManager = authManager;
        this.jwtService = jwtService;
    }

    public AuthDtos.AuthResponse register(AuthDtos.RegisterRequest req) {
        if (userRepository.existsByEmail(req.email())) {
            throw new ConflictException("Email already in use");
        }
        if (userRepository.existsByUsername(req.username())) {
            throw new ConflictException("Username already taken");
        }

        User user = new User();
        user.setUsername(req.username());
        user.setEmail(req.email().toLowerCase());
        user.setPasswordHash(passwordEncoder.encode(req.password()));
        user.setDisplayName(req.displayName() != null && !req.displayName().isBlank()
                ? req.displayName() : req.username());

        User saved = userRepository.save(user);
        return issueTokens(saved);
    }

    public AuthDtos.AuthResponse login(AuthDtos.LoginRequest req) {
        try {
            Authentication auth = authManager.authenticate(
                    new UsernamePasswordAuthenticationToken(req.identifier(), req.password()));
            // Resolve the actual user from DB so we have the full profile
            User user = userRepository.findByEmail(auth.getName())
                    .or(() -> userRepository.findByUsername(auth.getName()))
                    .orElseThrow(() -> new BadCredentialsException("Invalid credentials"));
            return issueTokens(user);
        } catch (org.springframework.security.core.AuthenticationException ex) {
            throw new BadCredentialsException("Invalid credentials");
        }
    }

    public AuthDtos.AuthResponse refresh(AuthDtos.RefreshRequest req) {
        String userId;
        try {
            if (!jwtService.isRefreshToken(req.refreshToken())) {
                throw new BadCredentialsException("Not a refresh token");
            }
            userId = jwtService.extractUserId(req.refreshToken());
        } catch (JwtException | IllegalArgumentException ex) {
            throw new BadCredentialsException("Invalid refresh token");
        }
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new NotFoundException("User not found"));
        return issueTokens(user);
    }

    private AuthDtos.AuthResponse issueTokens(User user) {
        String access = jwtService.generateAccessToken(user.getId());
        String refresh = jwtService.generateRefreshToken(user.getId());
        return new AuthDtos.AuthResponse(
                access, refresh,
                jwtService.getAccessTokenTtlSeconds(),
                UserDtos.UserProfile.from(user)
        );
    }
}
