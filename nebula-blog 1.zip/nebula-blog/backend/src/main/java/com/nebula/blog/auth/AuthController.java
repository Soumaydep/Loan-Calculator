package com.nebula.blog.auth;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/register")
    public ResponseEntity<AuthDtos.AuthResponse> register(@Valid @RequestBody AuthDtos.RegisterRequest req) {
        return ResponseEntity.status(201).body(authService.register(req));
    }

    @PostMapping("/login")
    public AuthDtos.AuthResponse login(@Valid @RequestBody AuthDtos.LoginRequest req) {
        return authService.login(req);
    }

    @PostMapping("/refresh")
    public AuthDtos.AuthResponse refresh(@Valid @RequestBody AuthDtos.RefreshRequest req) {
        return authService.refresh(req);
    }

    /**
     * NOTE: With pure JWT, logout is client-side (drop the token).
     * EXTENSION POINT: implement a refresh-token blacklist (Redis) for hard logout.
     */
    @PostMapping("/logout")
    public ResponseEntity<Void> logout() {
        return ResponseEntity.noContent().build();
    }

    /**
     * EXTENSION POINT: OAuth2 Google/GitHub login.
     * Add `spring-boot-starter-oauth2-client`, configure providers in application.properties,
     * and exchange the OAuth2 principal for a Nebula JWT here. Frontend redirects to /oauth2/authorization/google.
     */
}
