package com.nebula.blog.post;

import com.nebula.blog.common.PageResponse;
import com.nebula.blog.security.CurrentUser;
import com.nebula.blog.security.UserPrincipal;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/posts")
public class PostController {

    private final PostService postService;

    public PostController(PostService postService) {
        this.postService = postService;
    }

    @GetMapping
    public PageResponse<PostDtos.PostSummary> list(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "12") int size,
            @RequestParam(required = false) String tag,
            @RequestParam(required = false) String search) {
        return postService.listPublished(page, size, tag, search);
    }

    @GetMapping("/by-author/{authorId}")
    public PageResponse<PostDtos.PostSummary> listByAuthor(
            @PathVariable String authorId,
            @RequestParam(required = false) Post.Status status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "12") int size) {
        return postService.listByAuthor(authorId, status, page, size);
    }

    @GetMapping("/{slug}")
    public PostDtos.PostDetail getBySlug(
            @PathVariable String slug,
            @CurrentUser UserPrincipal principal,
            @RequestParam(defaultValue = "true") boolean track) {
        String userId = principal == null ? null : principal.getId();
        return postService.getBySlug(slug, userId, track);
    }

    @PostMapping
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<PostDtos.PostDetail> create(
            @CurrentUser UserPrincipal principal,
            @Valid @RequestBody PostDtos.CreatePostRequest req) {
        return ResponseEntity.status(201).body(postService.create(principal.getId(), req));
    }

    @PatchMapping("/{postId}")
    @PreAuthorize("isAuthenticated()")
    public PostDtos.PostDetail update(
            @CurrentUser UserPrincipal principal,
            @PathVariable String postId,
            @Valid @RequestBody PostDtos.UpdatePostRequest req) {
        return postService.update(postId, principal.getId(), req);
    }

    @DeleteMapping("/{postId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Void> delete(
            @CurrentUser UserPrincipal principal,
            @PathVariable String postId) {
        postService.delete(postId, principal.getId());
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{postId}/like")
    @PreAuthorize("isAuthenticated()")
    public PostDtos.PostDetail toggleLike(
            @CurrentUser UserPrincipal principal,
            @PathVariable String postId) {
        return postService.toggleLike(postId, principal.getId());
    }

    @PostMapping("/{postId}/bookmark")
    @PreAuthorize("isAuthenticated()")
    public PostDtos.PostDetail toggleBookmark(
            @CurrentUser UserPrincipal principal,
            @PathVariable String postId) {
        return postService.toggleBookmark(postId, principal.getId());
    }
}
