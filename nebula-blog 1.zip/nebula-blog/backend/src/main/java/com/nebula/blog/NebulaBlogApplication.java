package com.nebula.blog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.config.EnableMongoAuditing;

@SpringBootApplication
@EnableMongoAuditing
public class NebulaBlogApplication {
    public static void main(String[] args) {
        SpringApplication.run(NebulaBlogApplication.class, args);
    }
}
