package com.nebula.blog.post;

import com.nebula.blog.common.PageResponse;
import com.nebula.blog.exception.ForbiddenException;
import com.nebula.blog.exception.NotFoundException;
import com.nebula.blog.user.User;
import com.nebula.blog.user.UserDtos;
import com.nebula.blog.user.UserRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class PostService {

    private final PostRepository postRepository;
    private final UserRepository userRepository;

    public PostService(PostRepository postRepository, UserRepository userRepository) {
        this.postRepository = postRepository;
        this.userRepository = userRepository;
    }

    public PostDtos.PostDetail create(String authorId, PostDtos.CreatePostRequest req) {
        Post post = new Post();
        applyCreate(post, authorId, req);
        Post saved = postRepository.save(post);
        return toDetail(saved, authorId);
    }

    private void applyCreate(Post post, String authorId, PostDtos.CreatePostRequest req) {
        post.setAuthorId(authorId);
        post.setTitle(req.title());
        post.setExcerpt(buildExcerpt(req.excerpt(), req.content()));
        post.setContent(req.content());
        post.setCoverImageUrl(req.coverImageUrl());
        post.setTags(req.tags() == null ? List.of() : req.tags());
        post.setReadingMinutes(PostUtils.estimateReadingMinutes(req.content()));
        post.setSlug(generateUniqueSlug(req.title()));
        if (req.publish()) {
            post.setStatus(Post.Status.PUBLISHED);
            post.setPublishedAt(Instant.now());
        } else {
            post.setStatus(Post.Status.DRAFT);
        }
    }

    public PostDtos.PostDetail update(String postId, String userId, PostDtos.UpdatePostRequest req) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new NotFoundException("Post not found"));
        if (!post.getAuthorId().equals(userId)) {
            throw new ForbiddenException("You cannot edit this post");
        }
        if (req.title() != null) {
            post.setTitle(req.title());
            // We keep the original slug for stability; uncomment to regenerate:
            // post.setSlug(generateUniqueSlug(req.title()));
        }
        if (req.excerpt() != null) post.setExcerpt(req.excerpt());
        if (req.content() != null) {
            post.setContent(req.content());
            post.setReadingMinutes(PostUtils.estimateReadingMinutes(req.content()));
        }
        if (req.coverImageUrl() != null) post.setCoverImageUrl(req.coverImageUrl());
        if (req.tags() != null) post.setTags(req.tags());
        if (req.status() != null) {
            if (req.status() == Post.Status.PUBLISHED && post.getPublishedAt() == null) {
                post.setPublishedAt(Instant.now());
            }
            post.setStatus(req.status());
        }
        return toDetail(postRepository.save(post), userId);
    }

    public void delete(String postId, String userId) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new NotFoundException("Post not found"));
        if (!post.getAuthorId().equals(userId)) {
            throw new ForbiddenException("You cannot delete this post");
        }
        postRepository.delete(post);
    }

    public PostDtos.PostDetail getBySlug(String slug, String currentUserId, boolean incrementView) {
        Post post = postRepository.findBySlug(slug)
                .orElseThrow(() -> new NotFoundException("Post not found"));
        if (post.getStatus() != Post.Status.PUBLISHED &&
                (currentUserId == null || !currentUserId.equals(post.getAuthorId()))) {
            throw new NotFoundException("Post not found");
        }
        if (incrementView && post.getStatus() == Post.Status.PUBLISHED) {
            post.setViewCount(post.getViewCount() + 1);
            postRepository.save(post);
        }
        return toDetail(post, currentUserId);
    }

    public PageResponse<PostDtos.PostSummary> listPublished(int page, int size, String tag, String search) {
        Pageable pageable = PageRequest.of(page, Math.min(size, 50),
                Sort.by(Sort.Direction.DESC, "publishedAt"));
        Page<Post> result;
        if (search != null && !search.isBlank()) {
            result = postRepository.searchPublished(search, Post.Status.PUBLISHED, pageable);
        } else if (tag != null && !tag.isBlank()) {
            result = postRepository.findByStatusAndTagsIn(Post.Status.PUBLISHED, List.of(tag), pageable);
        } else {
            result = postRepository.findByStatus(Post.Status.PUBLISHED, pageable);
        }
        return mapPageToSummaries(result);
    }

    public PageResponse<PostDtos.PostSummary> listByAuthor(String authorId, Post.Status status, int page, int size) {
        Pageable pageable = PageRequest.of(page, Math.min(size, 50),
                Sort.by(Sort.Direction.DESC, "updatedAt"));
        Page<Post> result = (status == null)
                ? postRepository.findByAuthorId(authorId, pageable)
                : postRepository.findByAuthorIdAndStatus(authorId, status, pageable);
        return mapPageToSummaries(result);
    }

    public PostDtos.PostDetail toggleLike(String postId, String userId) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new NotFoundException("Post not found"));
        if (!post.getLikedBy().add(userId)) {
            post.getLikedBy().remove(userId);
        }
        return toDetail(postRepository.save(post), userId);
    }

    public PostDtos.PostDetail toggleBookmark(String postId, String userId) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new NotFoundException("Post not found"));
        if (!post.getBookmarkedBy().add(userId)) {
            post.getBookmarkedBy().remove(userId);
        }
        return toDetail(postRepository.save(post), userId);
    }

    // ---------- helpers ----------

    private PageResponse<PostDtos.PostSummary> mapPageToSummaries(Page<Post> page) {
        Map<String, User> authors = loadAuthorsFor(page.getContent());
        return PageResponse.from(page).map(p -> toSummary(p, authors.get(p.getAuthorId())));
    }

    private Map<String, User> loadAuthorsFor(List<Post> posts) {
        List<String> ids = posts.stream().map(Post::getAuthorId).distinct().toList();
        Map<String, User> map = new HashMap<>();
        userRepository.findAllById(ids).forEach(u -> map.put(u.getId(), u));
        return map;
    }

    private PostDtos.PostSummary toSummary(Post p, User author) {
        return new PostDtos.PostSummary(
                p.getId(), p.getSlug(), p.getTitle(), p.getExcerpt(), p.getCoverImageUrl(),
                p.getTags(),
                author == null ? null : UserDtos.UserSummary.from(author),
                p.getReadingMinutes() == null ? 1 : p.getReadingMinutes(),
                p.getViewCount(), p.getLikedBy().size(),
                p.getStatus(), p.getPublishedAt(), p.getUpdatedAt()
        );
    }

    private PostDtos.PostDetail toDetail(Post p, String currentUserId) {
        User author = userRepository.findById(p.getAuthorId()).orElse(null);
        return new PostDtos.PostDetail(
                p.getId(), p.getSlug(), p.getTitle(), p.getExcerpt(), p.getContent(),
                p.getCoverImageUrl(), p.getTags(),
                author == null ? null : UserDtos.UserSummary.from(author),
                p.getReadingMinutes() == null ? 1 : p.getReadingMinutes(),
                p.getViewCount(), p.getLikedBy().size(), p.getBookmarkedBy().size(),
                currentUserId != null && p.getLikedBy().contains(currentUserId),
                currentUserId != null && p.getBookmarkedBy().contains(currentUserId),
                p.getStatus(), p.getPublishedAt(), p.getCreatedAt(), p.getUpdatedAt()
        );
    }

    private String buildExcerpt(String provided, String content) {
        if (provided != null && !provided.isBlank()) return provided;
        if (content == null) return "";
        String stripped = content.replaceAll("[#*_`>\\-]+", " ").replaceAll("\\s+", " ").trim();
        return stripped.length() <= 240 ? stripped : stripped.substring(0, 240) + "…";
    }

    private String generateUniqueSlug(String title) {
        String base = PostUtils.slugify(title);
        if (base.isEmpty()) base = "post";
        String candidate = base;
        int suffix = 1;
        while (postRepository.existsBySlug(candidate)) {
            suffix++;
            candidate = base + "-" + suffix;
            if (suffix > 50) {
                candidate = base + "-" + System.currentTimeMillis();
                break;
            }
        }
        return candidate;
    }
}
