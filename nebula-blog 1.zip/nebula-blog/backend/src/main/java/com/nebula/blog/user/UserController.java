package com.nebula.blog.user;

import com.nebula.blog.security.CurrentUser;
import com.nebula.blog.security.UserPrincipal;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/me")
    @PreAuthorize("isAuthenticated()")
    public UserDtos.UserProfile me(@CurrentUser UserPrincipal principal) {
        return UserDtos.UserProfile.from(userService.getById(principal.getId()));
    }

    @PatchMapping("/me")
    @PreAuthorize("isAuthenticated()")
    public UserDtos.UserProfile updateMe(
            @CurrentUser UserPrincipal principal,
            @Valid @RequestBody UserDtos.UpdateProfileRequest req) {
        return UserDtos.UserProfile.from(userService.updateProfile(principal.getId(), req));
    }

    @GetMapping("/{username}")
    public UserDtos.UserProfile getByUsername(@PathVariable String username) {
        return UserDtos.UserProfile.from(userService.getByUsername(username));
    }

    @PostMapping("/{userId}/follow")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Void> follow(
            @CurrentUser UserPrincipal principal,
            @PathVariable String userId) {
        userService.follow(principal.getId(), userId);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{userId}/follow")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Void> unfollow(
            @CurrentUser UserPrincipal principal,
            @PathVariable String userId) {
        userService.unfollow(principal.getId(), userId);
        return ResponseEntity.noContent().build();
    }
}
