# A Birthday To Remember 🎂♥

A 3D-animated birthday website for the love of your life.

## How to use it (the 30-second version)

1. **Double-click `index.html`** — it opens in your browser. That's it.
2. Edit the file to personalise it (see below). Open it in any text editor —
   look for the comments marked `═══ PERSONALISE ═══`.

## What's inside

```
birthday_for_my_love/
├── index.html              ← the website (single self-contained file)
├── Birthday_Plan.docx      ← the 7-page design & implementation document
├── README.md               ← this file
└── assets/
    └── photos/             ← (optional) drop her photos here for the gallery
```

## What to personalise

There are 5 things to change, all clearly marked with comments in `index.html`:

| What | Where to find it |
|---|---|
| **Her name** | Search for `[Her Name]` near the top of the file |
| **The date** | Search for `BIRTHDAY_DATE` — set it to her actual birthday |
| **The love letter** | Find the comment `PERSONALISE: rewrite this letter in your own voice` |
| **The 3 gift box messages** | Find `PERSONALISE: change these three messages` |
| **The hidden secret message** | Find `PERSONALISE: SECRET HIDDEN MESSAGE` |

## What it includes

- **Floating hearts background** — ambient, drifting hearts in soft pinks
- **Name reveal** — her name with a shimmering rose-gold gradient
- **Live countdown** — flip-style digits ticking down to her birthday
- **3D cake** — Three.js-rendered three-tier cake with flickering candles
  (falls back to a beautiful CSS cake if Three.js can't load)
- **Tap candles to blow them out** — each one fades with a smoke wisp
- **Make a wish** — text input with a sealing animation
- **Confetti burst** — 320-piece physics confetti when she seals her wish
- **Memory gallery** — 6 photo cards with parallax (drop in your photos)
- **3D gift boxes** — three rotating gifts that open with a flip animation
- **Long-form love letter** — glassmorphic card with serif typography
- **Floating balloons release** — 30 balloons rising up across the screen
- **Hidden secret message** — click the ♥ in the bottom-right corner 3 times

## Optional: Add real photos

Drop her photos into `assets/photos/` (square JPGs work best, ~800×800px),
then in `index.html` find the gallery section and add image paths:

```html
<div class="memory-card" data-img="assets/photos/your_photo.jpg">
```

## Optional: Host it online

If you want her to access it from her phone via a link instead of having to
open a file:

1. Go to https://app.netlify.com/drop
2. Drag this entire folder onto the page
3. You'll get a link like `pretty-rose-12345.netlify.app` to share with her

It takes about 30 seconds and is completely free.

## Hand-off ideas

Three nice ways to give it to her:

1. **Midnight call** — open the page on your phone at 12:00 AM and hand it
   to her, wrapped in a ribbon if you have one
2. **First-thing-in-the-morning text** — host it on Netlify and message her
   the link with no explanation
3. **Email zip** — send her this folder zipped, with the message
   "unzip and double-click index.html"

## Browser support

Works on Chrome, Edge, Safari, Firefox (last 2 versions of each), iOS Safari
15+ and Android Chrome 100+.

## Privacy

- No tracking, no analytics, no third-party scripts (except Three.js from
  the CDN and Google Fonts)
- Wishes she types are stored only in her browser — never sent anywhere
- Works fully offline once loaded once

---

Made with love. Happy birthday to her, from you. ♥
